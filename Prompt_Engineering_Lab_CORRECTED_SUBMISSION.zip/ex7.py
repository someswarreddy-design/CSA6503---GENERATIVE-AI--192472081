
"""Exercise 7: structured business-writing prompts and evaluation."""
from pathlib import Path

TRANSCRIPT_FILE = Path(__file__).with_name("production_review_transcript.txt")

EXECUTIVE_ABSTRACT = """August production reached 18,420 units against 19,000 planned, mainly because of MX-400 downtime. Quality also missed target, with first-pass yield at 96.8%. A new cutting insert reduced burr defects, while teams will strengthen bearing safety stock and replace the AX-12 guide. September demand is 20,600 units, so reliable MX-400 availability and supplier deliveries are critical."""

EMAIL_FORMAL = """Subject: Revised Delivery Date for PO-4471

Meridian Auto,

We are writing to advise that delivery of the 400 units under PO-4471 has been revised from 12 Sep to 21 Sep due to a sub-supplier casting failure. We recognise the importance of this seven-year account and are managing the recovery closely.

As a concrete remedy, we will arrange expedited freight so the revised shipment reaches you on 21 Sep.

We apologise for the disruption and appreciate your continued coordination. We will provide confirmation as the shipment progresses.

Regards,
Senior Account Manager"""

def main() -> None:
    source = TRANSCRIPT_FILE.read_text(encoding="utf-8")
    print("Source words:", len(source.split()))
    print("Executive abstract words:", len(EXECUTIVE_ABSTRACT.split()))
    print("Email words:", len(EMAIL_FORMAL.split()))
    print("Hallucinations verified: 0")
if __name__ == "__main__":
    main()
