
"""Exercise 9: generated SQL + Python report verification."""
from pathlib import Path
import sqlite3
import pandas as pd

DB = Path(__file__).with_name("retail_sales.db")
QUERIES = {
    "Query 1 \u2014 MoM growth": "WITH valid_sales AS (\n    SELECT o.order_date, oi.prod_id,\n           oi.qty * p.unit_price * (1 - oi.discount_pct / 100.0) AS revenue\n    FROM orders o\n    JOIN order_items oi ON o.order_id = oi.order_id\n    JOIN products p ON oi.prod_id = p.prod_id\n    WHERE o.status <> 'CANCELLED'\n),\nmonthly AS (\n    SELECT strftime('%Y-%m', order_date) AS month,\n           p.category,\n           SUM(v.revenue) AS revenue\n    FROM valid_sales v\n    JOIN products p ON v.prod_id = p.prod_id\n    WHERE date(order_date) >= date((SELECT MAX(order_date) FROM orders), '-11 months')\n    GROUP BY month, p.category\n),\nwith_prev AS (\n    SELECT category, month, revenue,\n           LAG(revenue) OVER (PARTITION BY category ORDER BY month) AS prev_revenue\n    FROM monthly\n)\nSELECT category, month,\n       ROUND(revenue, 2) AS revenue,\n       ROUND((revenue - prev_revenue) * 100.0 / NULLIF(prev_revenue, 0), 2) AS mom_growth_pct\nFROM with_prev\nORDER BY month, category;",
    "Query 2 \u2014 Top 5 LTV": "WITH valid_ltv AS (\n    SELECT c.cust_id, c.name,\n           SUM(oi.qty * p.unit_price * (1 - oi.discount_pct / 100.0)) AS lifetime_value\n    FROM customers c\n    JOIN orders o ON c.cust_id = o.cust_id\n    JOIN order_items oi ON o.order_id = oi.order_id\n    JOIN products p ON oi.prod_id = p.prod_id\n    WHERE o.status <> 'CANCELLED'\n    GROUP BY c.cust_id, c.name\n)\nSELECT cust_id, name, ROUND(lifetime_value, 2) AS lifetime_value\nFROM valid_ltv\nORDER BY lifetime_value DESC\nLIMIT 5;",
    "Query 3 \u2014 QoQ drop": "WITH valid_sales AS (\n    SELECT oi.prod_id, o.order_date,\n           oi.qty * p.unit_price * (1 - oi.discount_pct / 100.0) AS revenue\n    FROM orders o\n    JOIN order_items oi ON o.order_id = oi.order_id\n    JOIN products p ON oi.prod_id = p.prod_id\n    WHERE o.status <> 'CANCELLED'\n),\nquarterly AS (\n    SELECT prod_id,\n           strftime('%Y', order_date) || '-Q' ||\n           CAST(((CAST(strftime('%m', order_date) AS INTEGER) - 1) / 3) + 1 AS INTEGER) AS quarter,\n           SUM(revenue) AS revenue\n    FROM valid_sales\n    GROUP BY prod_id, quarter\n),\nwith_prev AS (\n    SELECT prod_id, quarter, revenue,\n           LAG(revenue) OVER (PARTITION BY prod_id ORDER BY quarter) AS prev_revenue\n    FROM quarterly\n)\nSELECT p.prod_id, p.name, quarter,\n       ROUND(revenue, 2) AS revenue,\n       ROUND((revenue - prev_revenue) * 100.0 / NULLIF(prev_revenue, 0), 2) AS qoq_change_pct\nFROM with_prev w\nJOIN products p ON p.prod_id = w.prod_id\nWHERE prev_revenue IS NOT NULL\n  AND revenue < prev_revenue * 0.70\nORDER BY qoq_change_pct;",
    "Query 4 \u2014 Churn": "WITH q1 AS (\n    SELECT DISTINCT cust_id\n    FROM orders\n    WHERE status <> 'CANCELLED'\n      AND order_date >= '2026-01-01' AND order_date < '2026-04-01'\n),\nq2 AS (\n    SELECT DISTINCT cust_id\n    FROM orders\n    WHERE status <> 'CANCELLED'\n      AND order_date >= '2026-04-01' AND order_date < '2026-07-01'\n)\nSELECT c.cust_id, c.name, c.city, c.segment\nFROM customers c\nJOIN q1 ON c.cust_id = q1.cust_id\nLEFT JOIN q2 ON c.cust_id = q2.cust_id\nWHERE q2.cust_id IS NULL\nORDER BY c.cust_id;"
}

def run_queries():
    """Execute every generated SQL query and print results."""
    with sqlite3.connect(DB) as con:
        for name, query in QUERIES.items():
            print("\n" + name)
            df = pd.read_sql_query(query, con)
            print(df.to_string(index=False))

def main():
    run_queries()

if __name__ == "__main__":
    main()
