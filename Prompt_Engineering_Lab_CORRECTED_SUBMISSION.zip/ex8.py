
"""Exercise 8: LLM advisory generator with secure API access and fallback.
Set OPENAI_API_KEY before execution for live API generation.
Without a key, the required static fallback path is executed.
"""
from __future__ import annotations

import csv
import os
import time
from pathlib import Path
from typing import Dict

PROMPT = (
    "You are an agricultural extension officer.\n"
    "Write ONE advisory SMS under 160 characters in {language}.\n"
    "Crop: {crop} | District: {district} | Soil: {soil} | Weather: {weather}\n"
    "Rules: one actionable instruction, no greetings, no emojis, "
    "no chemical dosage without units, plain words only."
)

FALLBACK_TEMPLATE = "Water the {crop} in {district} according to soil moisture; avoid over-irrigation during {weather} conditions."

def generate_advisory(params: dict, temperature: float = 0.3, top_p: float = 1.0) -> dict:
    """Generate an advisory, using an API when configured and a safe fallback otherwise."""
    prompt = PROMPT.format(**params)
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        text = FALLBACK_TEMPLATE.format(**params)
        return {"text": text[:159], "latency_ms": 0.0, "in_tokens": 0, "out_tokens": 0, "estimated_cost": 0.0, "mode": "fallback"}

    # Optional live-provider section. Requires the openai package.
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        t0 = time.time()
        resp = client.responses.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            input=prompt,
            temperature=temperature,
            top_p=top_p,
            max_output_tokens=120,
        )
        latency = (time.time() - t0) * 1000
        text = resp.output_text.strip()
        usage = getattr(resp, "usage", None)
        in_tokens = getattr(usage, "input_tokens", 0) if usage else 0
        out_tokens = getattr(usage, "output_tokens", 0) if usage else 0
        return {"text": text, "latency_ms": round(latency, 1), "in_tokens": in_tokens,
                "out_tokens": out_tokens, "estimated_cost": 0.0, "mode": "api"}
    except Exception:
        text = FALLBACK_TEMPLATE.format(**params)
        return {"text": text[:159], "latency_ms": 0.0, "in_tokens": 0, "out_tokens": 0, "estimated_cost": 0.0, "mode": "fallback"}

PROFILES = [
{"crop":"rice","district":"Chittoor","soil":"loamy","weather":"hot and dry","language":"English"},
{"crop":"groundnut","district":"Anantapur","soil":"sandy loam","weather":"dry","language":"English"},
{"crop":"tomato","district":"Kolar","soil":"red soil","weather":"cloudy","language":"English"},
{"crop":"paddy","district":"Nellore","soil":"clay","weather":"humid","language":"English"},
{"crop":"chilli","district":"Guntur","soil":"black soil","weather":"hot","language":"English"},
{"crop":"maize","district":"Kadapa","soil":"red loam","weather":"dry","language":"English"},
{"crop":"cotton","district":"Warangal","soil":"black soil","weather":"warm","language":"English"},
{"crop":"sugarcane","district":"Mandya","soil":"loamy","weather":"humid","language":"English"},
{"crop":"banana","district":"Thanjavur","soil":"alluvial","weather":"humid","language":"English"},
{"crop":"millet","district":"Dharmapuri","soil":"sandy loam","weather":"dry","language":"English"},
]

def main() -> None:
    sweep = [
        (0.0, 1.0), (0.4, 1.0), (0.9, 1.0), (0.4, 0.5), (0.9, 0.5)
    ]
    for temp, top_p in sweep:
        result = generate_advisory(PROFILES[0], temp, top_p)
        print(temp, top_p, result)
    out = Path(__file__).with_name("exercise8_advisories.csv")
    with out.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["crop","district","soil","weather","language","text","latency_ms","in_tokens","out_tokens","estimated_cost","mode"])
        writer.writeheader()
        for p in PROFILES:
            r = generate_advisory(p)
            writer.writerow({**p, **r})
    print("CSV:", out)

if __name__ == "__main__":
    main()
