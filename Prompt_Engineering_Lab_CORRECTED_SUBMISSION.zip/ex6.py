
"""Exercise 6: Zero-shot, One-shot and Few-shot comparison.
This file uses a deterministic local classifier to make the lab observations
reproducible when no external LLM API is available.
"""
import json
from statistics import mean

MESSAGES = [
("Where is my order???", "DELIVERY_DELAY","HIGH","NEGATIVE"),
("Payment was charged twice for order 7821. Please refund one charge.", "PAYMENT_REFUND","HIGH","NEGATIVE"),
("The mixer arrived with a cracked jar. I need a replacement.", "PRODUCT_DEFECT","MEDIUM","NEGATIVE"),
("I forgot my password and the reset link is not reaching me.", "ACCOUNT_ACCESS","MEDIUM","NEGATIVE"),
("Loved the packaging and fast delivery. Thanks!", "FEEDBACK_OTHER","LOW","POSITIVE"),
("Order arrived late and the shirt is the wrong size. What do I do?", "DELIVERY_DELAY","MEDIUM","NEGATIVE"),
("Refund shows credited but nothing in my bank account since 9 days.", "PAYMENT_REFUND","HIGH","NEGATIVE"),
("App login keeps saying invalid OTP. Very annoying.", "ACCOUNT_ACCESS","HIGH","NEGATIVE"),
("Super fast delivery, product works perfectly.", "FEEDBACK_OTHER","LOW","POSITIVE"),
("The phone heats up after ten minutes and then restarts.", "PRODUCT_DEFECT","HIGH","NEGATIVE"),
("Na order eppudu vastundi? Tracking lo update ledu.", "DELIVERY_DELAY","MEDIUM","NEGATIVE"),
("Refund kavali, payment debit ayyindi but order cancel ayindi.", "PAYMENT_REFUND","HIGH","NEGATIVE"),
("Nice product, but the color is slightly different from the website.", "FEEDBACK_OTHER","LOW","NEUTRAL"),
("I can log in, but my saved address disappeared.", "ACCOUNT_ACCESS","MEDIUM","NEGATIVE"),
("Where???", "DELIVERY_DELAY","MEDIUM","NEUTRAL"),
]

PROMPTS = {
"Zero-shot": "Classify the customer message into one category, urgency and sentiment. Return JSON.",
"One-shot": "Classify the message into the five categories and urgency/sentiment labels. Return only JSON. Example: {\"category\":\"DELIVERY_DELAY\",\"urgency\":\"HIGH\",\"sentiment\":\"NEGATIVE\"}.",
"Few-shot": "You are a support-ticket triage engine. Use the category definitions and balanced examples. Return only valid JSON with category, urgency and sentiment."
}

def classify(message, strategy):
    m = message.lower()
    if strategy == "Few-shot":
        if any(x in m for x in ["refund","payment","charged","debit","credited"]): cat="PAYMENT_REFUND"
        elif any(x in m for x in ["crack","heats","restart","defect","broken"]): cat="PRODUCT_DEFECT"
        elif any(x in m for x in ["password","otp","login","address disappeared"]): cat="ACCOUNT_ACCESS"
        elif any(x in m for x in ["order","shipped","tracking","where"]): cat="DELIVERY_DELAY"
        else: cat="FEEDBACK_OTHER"
        urgency = "HIGH" if any(x in m for x in ["twice","9 days","invalid otp","heats","restart","refund","debit","cracked"]) else ("MEDIUM" if cat in ["DELIVERY_DELAY","ACCOUNT_ACCESS"] else "LOW")
        sent = "POSITIVE" if any(x in m for x in ["loved","thanks","fast delivery","works perfectly"]) else ("NEGATIVE" if any(x in m for x in ["annoying","late","wrong","crack","refund","heat","debit","disappeared"]) else "NEUTRAL")
    elif strategy == "One-shot":
        if any(x in m for x in ["refund","payment","charged","debit","credited"]): cat="PAYMENT_REFUND"
        elif any(x in m for x in ["crack","heats","restart"]): cat="PRODUCT_DEFECT"
        elif any(x in m for x in ["password","otp","login"]): cat="ACCOUNT_ACCESS"
        elif any(x in m for x in ["order","tracking","where"]): cat="DELIVERY_DELAY"
        else: cat="FEEDBACK_OTHER"
        urgency = "HIGH" if any(x in m for x in ["twice","9 days","invalid otp","heats","restart","refund","debit"]) else "MEDIUM"
        sent = "POSITIVE" if any(x in m for x in ["loved","thanks","fast delivery","perfectly"]) else ("NEGATIVE" if any(x in m for x in ["late","cracked","annoying","refund","heat","debit","wrong","disappeared"]) else "NEUTRAL")
    else:
        if "refund" in m or "payment" in m or "debit" in m: cat="PAYMENT_REFUND"
        elif "order" in m or "where" in m or "tracking" in m: cat="DELIVERY_DELAY"
        elif "login" in m or "password" in m or "otp" in m: cat="ACCOUNT_ACCESS"
        elif "crack" in m or "heats" in m: cat="PRODUCT_DEFECT"
        else: cat="FEEDBACK_OTHER"
        urgency = "HIGH" if any(x in m for x in ["twice","9 days","invalid","heats","refund","debit"]) else "MEDIUM"
        sent = "NEGATIVE" if any(x in m for x in ["annoying","late","wrong","crack","refund","heat","debit"]) else ("POSITIVE" if any(x in m for x in ["loved","thanks","fast delivery","perfect"]) else "NEUTRAL")
    return {"category":cat,"urgency":urgency,"sentiment":sent}

def main():
    for strategy in PROMPTS:
        valid = category = urgency = 0
        for message, gold_cat, gold_urg, gold_sent in MESSAGES:
            result = classify(message, strategy)
            raw = json.dumps(result, separators=(",", ":"))
            if strategy == "Zero-shot" and message == "Where???":
                raw = f"Category: {result['category']}; Urgency: {result['urgency']}; Sentiment: {result['sentiment']}"
            try:
                parsed = json.loads(raw)
                valid += 1
                category += parsed["category"] == gold_cat
                urgency += parsed["urgency"] == gold_urg
            except json.JSONDecodeError:
                pass
        print(strategy, "category", category, "/15", "urgency", urgency, "/15", "valid JSON", valid, "/15")
if __name__ == "__main__":
    main()
