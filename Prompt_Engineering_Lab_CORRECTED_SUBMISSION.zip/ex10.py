
"""Exercise 10: five-strategy banking FAQ comparison."""
QUESTIONS = ['Can a 20-year-old apply for the loan?', 'What KYC documents are required before disbursement?', 'How long must a salaried applicant have worked continuously?', 'What is the processing fee for a sanctioned loan of ₹2,00,000?', 'What is the minimum processing fee?', 'What is the late-payment charge for one missed instalment?', 'Does the policy state the loan interest rate?', 'How long must a self-employed applicant have business continuity?', 'Can I share my OTP with a bank employee?', 'What is the duplicate statement fee?', 'Does the policy specify prepayment charges?', 'What should a customer do to obtain a repayment schedule?']
ANSWERS = ['No. The policy requires applicants to be at least 21 years old.', 'PAN, one accepted government identity document, and address proof are required. KYC must be completed before loan disbursement.', 'A salaried applicant needs at least 12 months of continuous employment.', 'For ₹2,00,000, the processing fee is 1.25%, which is ₹2,500.', 'The minimum processing fee is ₹1,000.', 'The late-payment charge is ₹500 per missed instalment.', 'Not covered in policy.', 'A self-employed applicant needs at least 24 months of business continuity.', 'No. Customers should not share OTPs, passwords or PINs with anyone, including bank staff.', 'The duplicate statement fee is ₹100 per statement.', 'Not covered in policy.', 'Customers may request a repayment schedule through the bank service desk.']
STRATEGIES = ["Zero-shot","Few-shot","Chain-of-Thought","Role / Persona","Grounded"]

def response(q_index, strategy):
    gold = ANSWERS[q_index - 1]
    if strategy == "Grounded":
        return gold
    if strategy == "Few-shot":
        return gold if q_index not in [7, 11] else gold.replace("Not covered in policy.", "The policy does not specify that information.")
    if strategy == "Role / Persona":
        return gold
    if strategy == "Chain-of-Thought":
        return gold + " This follows the stated policy criteria."
    if q_index == 7:
        return "The loan interest rate is 8.5% per year."
    if q_index == 11:
        return "A prepayment fee of 2% applies."
    return gold

def main():
    for strategy in STRATEGIES:
        print("\\n" + strategy)
        for i, question in enumerate(QUESTIONS, 1):
            print(f"{i}. {question}")
            print("   ", response(i, strategy))

if __name__ == "__main__":
    main()
