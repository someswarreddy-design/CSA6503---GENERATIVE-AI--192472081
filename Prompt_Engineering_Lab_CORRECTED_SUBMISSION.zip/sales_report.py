"""Generate a category-wise sales report from SQLite and export to Excel."""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

import pandas as pd


DB_PATH = Path(__file__).with_name("retail_sales.db")
OUTPUT_XLSX = Path(__file__).with_name("sales_report.xlsx")


def load_category_revenue(db_path: Path) -> pd.DataFrame:
    """Return category-wise revenue using parameterized SQL."""
    query = """
        SELECT p.category AS category,
               ROUND(SUM(oi.qty * p.unit_price *
                         (1 - oi.discount_pct / 100.0)), 2) AS revenue
        FROM products AS p
        JOIN order_items AS oi ON p.prod_id = oi.prod_id
        JOIN orders AS o ON o.order_id = oi.order_id
        WHERE o.status <> ?
        GROUP BY p.category
        ORDER BY revenue DESC
    """
    with sqlite3.connect(db_path) as connection:
        return pd.read_sql_query(query, connection, params=("CANCELLED",))


def export_to_excel(df: pd.DataFrame, output_path: Path) -> None:
    """Export the revenue table and a bar chart to an Excel workbook."""
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="Revenue", index=False)
        worksheet = writer.sheets["Revenue"]
        from openpyxl.chart import BarChart, Reference

        chart = BarChart()
        chart.title = "Category-wise Revenue"
        chart.y_axis.title = "Revenue"
        chart.x_axis.title = "Category"
        data = Reference(worksheet, min_col=2, min_row=1, max_row=len(df) + 1)
        cats = Reference(worksheet, min_col=1, min_row=2, max_row=len(df) + 1)
        chart.add_data(data, titles_from_data=True)
        chart.set_categories(cats)
        worksheet.add_chart(chart, "D2")


def main() -> None:
    """Run the report generation."""
    df = load_category_revenue(DB_PATH)
    export_to_excel(df, OUTPUT_XLSX)
    print(df.to_string(index=False))
    print(f"Excel report written to: {OUTPUT_XLSX}")


if __name__ == "__main__":
    main()
